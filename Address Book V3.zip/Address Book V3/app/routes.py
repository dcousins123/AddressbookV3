from flask import render_template, request, flash, redirect, url_for
from flask_login import current_user, login_user, logout_user, login_required
from app import app, db
from app.forms import contactDetails, editcontact, importCSVFile, LoginForm, RegistrationForm
from app.models import contact, user
from pandas import pandas as pd
from werkzeug.urls import url_parse

#route /login is required for users to access the features of the site
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main'))
    form = LoginForm()
    if form.validate_on_submit():
        User = user.query.filter_by(username=form.username.data).first()
        if User is None or not User.check_password(form.password.data):
            flash('Invalid username or password')
            return redirect(url_for('login'))
        login_user(User, remember=form.remember_me.data)
        next_page = request.args.get('next')
        if not next_page or url_parse(next_page).netloc != '':
            next_page = url_for('main')
        return redirect(next_page)
    return render_template('login.html', title='Sign In', form=form)

#route /logout is used when a user logs out
@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('main'))

#route / is used for the home page
@app.route('/')
@app.route('/index')
@login_required
def main():
    form = contactDetails()
    return render_template('index.html', form=form)

#route /contacts is used to display all contacts
@app.route('/contacts')
@login_required
def contacts():
    Contacts = contact.query.all()
    return render_template('contacts.html', title='Contacts', rows=Contacts)

#route /addcontact is used to add a new contact to the db
@app.route('/addcontact', methods=['POST'])
@login_required
def addcontact():
    form = contactDetails()
    firstname = request.form['firstname']
    surname = request.form['surname']
    address = request.form['address']
    phone = request.form['phone']
    email = request.form['email']
    if form.validate_on_submit():
        Contact = contact(firstname=str(firstname), surname=str(surname), address=str(address), phone=int(phone), email=str(email))
        form.populate_obj(Contact)
        db.session.add(Contact)
        db.session.commit()
        flash('Congratulations, you have added a contact!')
        return redirect('/contacts')
    return render_template('index.html', title='Home', form=form)

#route /editcontact/ followed by contID is used to identify and edit particular contact record in db
@app.route('/editcontact/<contID>', methods=['GET', 'POST'])
@login_required
def editContact(contID):
    selectedContact = contact.query.filter_by(contID=contID).first()
    form = editcontact()
    if form.validate_on_submit():
        selectedContact.firstname = form.firstname.data
        selectedContact.surname = form.surname.data
        selectedContact.address = form.address.data
        selectedContact.phone = form.phone.data
        selectedContact.email = form.email.data
        db.session.commit()
        flash('Congratulations, you have edited a contact!')
        return redirect('/contacts')
    elif request.method == 'GET':
        form.contID.data = selectedContact.contID
        form.firstname.data = selectedContact.firstname
        form.surname.data = selectedContact.surname
        form.address.data = selectedContact.address
        form.phone.data = selectedContact.phone
        form.email.data = selectedContact.email
    return render_template('editcontact.html', title='Edit Contact', form=form)

#route /deletecontact/ followed by contID is used to delete a contact from edit page
@app.route('/deletecontact/<contID>', methods=['GET'])
@login_required
def deletecontact(contID):
    selectedContact = contact.query.filter_by(contID=contID).first()
    db.session.delete(selectedContact)
    db.session.commit()
    flash('Congratulations, you have deleted a contact!')
    return redirect('/contacts')

#route /import is used to import a csv file
@app.route('/import', methods=['GET', 'POST'])
@login_required
def importCon():
    form = importCSVFile()
    if form.validate_on_submit():
        df = pd.read_csv(request.files.get('fileChoice'))
        df.to_sql('contact', con=db.get_engine(), if_exists='append', index=False)
        flash('Congratulations, you have imported contact info!')
        return render_template('import.html', importContDisp=df.to_html(), form=form)
    return render_template('import.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        User = user(username=form.username.data, email=form.email.data)
        User.set_password(form.password.data)
        db.session.add(User)
        db.session.commit()
        flash('Congratulations, you are now a registered user!')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)