from app import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from app import login

class contact(db.Model):
    contID = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(32), nullable=False)
    surname = db.Column(db.String(32), nullable=False)
    address = db.Column(db.String(128), nullable=False)
    phone = db.Column(db.Integer, nullable=False)
    email = db.Column(db.String(64), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

    def __repr__(self):
        return '<Contact {}>'.format(self.contID)

class user(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), index=True, unique=True)
    email = db.Column(db.String(64), index=True, unique=True)
    password_hash = db.Column(db.String(32))

    def __repr__(self):
        return '<Contact {}>'.format(self.username)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@login.user_loader
def load_user(id):
    return user.query.get(int(id))