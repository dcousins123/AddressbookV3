from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField, FileField, BooleanField, PasswordField
from wtforms.validators import DataRequired, ValidationError, Email, EqualTo
from app.models import user

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')

class contactDetails(FlaskForm):
    firstname = StringField('First Name: ', validators=[DataRequired(message="Check field. No special chars.")])
    surname = StringField('Surname: ', validators=[DataRequired(message="Check field. No special chars.")])
    address = StringField('Address: ', validators=[DataRequired(message="Check field. No special chars.")])
    phone = IntegerField('Phone: ', validators=[DataRequired(message="Check field. Numerical chars.")])
    email = StringField('Email: ', validators=[DataRequired(message="Check field. Ensure email valid."), Email(message="This is not a valid email address")])
    submit = SubmitField('Add')

class editcontact(FlaskForm):
    contID = StringField('Contact ID: ', validators=[])
    firstname = StringField('First Name: ', validators=[DataRequired(message="Check field. No special chars.")])
    surname = StringField('Surname: ', validators=[DataRequired(message="Check field. No special chars.")])
    address = StringField('Address: ', validators=[DataRequired(message="Check field. No special chars.")])
    phone = IntegerField('Phone: ', validators=[DataRequired(message="Check field. Numerical chars.")])
    email = StringField('Email: ', validators=[DataRequired(message="Check field. Ensure email valid.")])
    submit = SubmitField('Update')

class importCSVFile(FlaskForm):
    fileChoice = FileField('CSV File: ', validators=[DataRequired(message="Please upload a valid CSV file.")])
    submit = SubmitField('Upload')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    password2 = PasswordField(
        'Repeat Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

    def validate_username(self, username):
        User = user.query.filter_by(username=username.data).first()
        if User is not None:
            raise ValidationError('Please use a different username.')

    def validate_email(self, email):
        User = user.query.filter_by(email=email.data).first()
        if User is not None:
            raise ValidationError('Please use a different email address.')