from app import app, db
from app.models import contact, user

@app.shell_context_processor
def make_shell_context():
    return {'db': db, 'contact': contact, 'user': user}